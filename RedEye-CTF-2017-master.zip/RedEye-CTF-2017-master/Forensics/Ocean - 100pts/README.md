#RedEye CTF 2017 : Ocean

* **Category**: Forensic <br>
* **Author**: Faid Mohammed Amine
* **Contact**: hello@faidamine.pw
* **Description**: 


$ foremost Ocean.jpg

and you get MissingPart.JPG Image

you need to repair the QR code as result you will get the final QR Code (Original.jpg)



# Write-up 

(TODO)

# Other write-ups and resources

