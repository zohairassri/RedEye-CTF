#RedEye CTF 2017 : No Time

* **Category**: Forensic <br>
* **Author**: Faid Mohammed Amine
* **Contact**: hello@faidamine.pw
* **Description**: 

run this script in the images directory

$ python Decode.py

Once you get the link inside the hidden qr code , and download the image from the link

let's start image processing  

$ python Image.py

and you get the flag


# Write-up 

(TODO)

# Other write-ups and resources

