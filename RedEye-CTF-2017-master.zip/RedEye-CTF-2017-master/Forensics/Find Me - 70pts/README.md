#RedEye CTF 2017 : Find Me

* **Category**: Forensic <br>
* **Author**: Faid Mohammed Amine
* **Contact**: hello@faidamine.pw
* **Description**: 

the AES Key is in Rockyou.txt



use the decryption python script to  get the flag 




# Write-up 

(TODO)

# Other write-ups and resources

