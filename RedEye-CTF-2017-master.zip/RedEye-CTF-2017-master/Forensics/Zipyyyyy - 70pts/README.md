#RedEye CTF 2017 : Zipyyyyy

* **Category**: Forensic <br>
* **Author**: Faid Mohammed Amine
* **Contact**: hello@faidamine.pw
* **Description**: 

we use rockyou.txt



use the decryption python script to  get the flag 




# Write-up 

(TODO)

# Other write-ups and resources

