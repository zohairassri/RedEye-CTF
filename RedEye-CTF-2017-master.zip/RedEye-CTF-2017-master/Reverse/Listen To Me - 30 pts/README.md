#RedEye CTF 2017 : Listen To Me

* **Category**: Reverse <br>
* **Author**: Faid Mohammed Amine
* **Contact**: hello@faidamine.pw
* **Description**: 

The attached file is .Net Executable

Once you decompile the the executable you will find the source code , the program is taking a string and encode it after that he send the flag into a specific port 31337

by using :  nc -vlp 31337

and you get the flag .



# Write-up 

(TODO)

# Other write-ups and resources

