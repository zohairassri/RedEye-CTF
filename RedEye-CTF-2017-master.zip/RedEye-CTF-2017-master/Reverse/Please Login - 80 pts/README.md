#RedEye CTF 2017 : Please Login

* **Category**: Reverse <br>
* **Author**: Faid Mohammed Amine
* **Contact**: hello@faidamine.pw
* **Description**: 

![](1.JPG)
<br>
gdb-peda$ b * 0x00000000004010b8
<br>
gdb-peda$ r
![](2.JPG)
<br>
![](3.JPG)

and we can see the username and the password




# Write-up 

(TODO)

# Other write-ups and resources

http://pwny.logdown.com/posts/2907424
